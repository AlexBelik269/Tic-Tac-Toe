﻿namespace WPF_TTT
{
    public enum WinType
    {
        //how can the game be won
        Row, Column, MainDiagonal, AntiDiagonal
    }
}
