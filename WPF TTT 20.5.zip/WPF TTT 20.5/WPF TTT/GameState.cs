﻿using System;


namespace WPF_TTT
{
    public class GameState
    {
        public Player[,] GameGrid { get; private set; }
        public Player CurrentPlayer { get; private set; }
        public int TurnsPassed { get; private set; }
        public bool GameOver { get; private set; }

        public event Action<int, int> MoveMade;
        public event Action<GameResult> GameEnded;
        public event Action GameRestarted;


        // every box has Player.None by default
        // X always plays first 
        public GameState()
        {
            GameGrid = new Player[3, 3];
            CurrentPlayer = Player.X;
            TurnsPassed = 0;
            GameOver = false;
        }







        // Helper methods:
        // Can player mark this box?
        // You can make a move if the game is not over and the box is empty
        private bool CanMakeMove(int r, int c)
        {
            return !GameOver && GameGrid[r, c] == Player.None;
        }

        // after 9 turns the Grid is full
        private bool IsGridFull()
        {
            return TurnsPassed == 9;
        }

        //after a move has been made, switch the Player
        private void SwitchPlayer()
        {
            if (CurrentPlayer == Player.X)
            {
                CurrentPlayer = Player.O;
            }
            else
            {
                CurrentPlayer = Player.X;
            }
        }
        // Has the Player won the game?
        // returns true if all the given boxes are marked by one player otherwise false
        private bool AreSquaresMarked((int, int)[] squares, Player player)
        {
            foreach ((int r, int c) in squares)
            {
                if (GameGrid[r, c] != player)
                {
                    return false;
                }
            }
            return true;
        }

        //Did the move win the game?
        private bool DidMoveWin(int r, int c, out WinInfo winInfo)
        {
            (int, int)[] row = new[] { (r, 0), (r, 1), (r, 2) };
            (int, int)[] col = new[] { (0, c), (1, c), (2, c) };
            (int, int)[] mainDiag = new[] { (0, 0), (1, 1), (2, 2) };
            (int, int)[] antiDiag = new[] { (0, 2), (1, 1), (2, 0) };
            // checks if the row is full, if true it saves the info in WinType 
            if (AreSquaresMarked(row, CurrentPlayer))
            {
                winInfo = new WinInfo { Type = WinType.Row, Number = r };
                return true;
            }
            // checks if the column is full, if true it saves the info in WinType 
            if (AreSquaresMarked(col, CurrentPlayer))
            {
                winInfo = new WinInfo { Type = WinType.Column, Number = c };
                return true;
            }
            // checks if the Diagonal from left top to right bottom is full, if true it saves the info in WinType 
            if (AreSquaresMarked(mainDiag, CurrentPlayer))
            {
                winInfo = new WinInfo { Type = WinType.MainDiagonal };
                return true;
            }
            // checks if the Diagonal from right top to left bottom is full, if true it saves the info in WinType
            if (AreSquaresMarked(antiDiag, CurrentPlayer))
            {
                winInfo = new WinInfo { Type = WinType.AntiDiagonal };
                return true;
            }

            // if none of these above return true the move did not win the game
            winInfo = null;
            return false;
        }

        // Checks if a move ended a game
        private bool DidMoveEndGame(int r, int c, out GameResult gameResult)
        {
            // if the move won the game the winner is the current player
            if (DidMoveWin(r, c, out WinInfo winInfo))
            {
                gameResult = new GameResult { Winner = CurrentPlayer, WinInfo = winInfo };
                return true;
            }
            // if the move didnt win the game but the grid is full its a tie
            if (IsGridFull())
            {
                gameResult = new GameResult { Winner = Player.None };
                return true;
            }
            // if none of these above return true the game did not end yet
            gameResult = null;
            return false;
        }








        //Public MakeMove method to chain the helper methods together

        public void MakeMove(int r, int c)
        {
            // if the move can not be played, it doesnt return anything
            if (!CanMakeMove(r, c))
            {
                return;
            }
            // if the move is possible, it gets done and the TurnsPassed increasses
            GameGrid[r, c] = CurrentPlayer;
            TurnsPassed++;
            //did the move end the game 
            if (DidMoveEndGame(r, c, out GameResult gameResult))
            {
                GameOver = true;
                MoveMade?.Invoke(r, c);
                GameEnded?.Invoke(gameResult);
            }
            else
            {
                SwitchPlayer();
                MoveMade?.Invoke(r, c);
            }
        } // Invoke "=" execute a methode


        // Reset the game 
        public void Reset()
        {
            GameGrid = new Player[3, 3];
            CurrentPlayer = Player.X;
            TurnsPassed = 0;
            GameOver = false;
            GameRestarted?.Invoke();
        }
    }
}
