﻿namespace WPF_TTT
{
    public enum Player
    {
        // sets possible players
        None, X, O
    }
}
