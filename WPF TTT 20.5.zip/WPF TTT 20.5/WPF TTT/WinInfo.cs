﻿namespace WPF_TTT
{
    public class WinInfo
    {
        //Saves how the game was won
        public WinType Type { get; set; }
        public int Number { get; set; }
    }
}
